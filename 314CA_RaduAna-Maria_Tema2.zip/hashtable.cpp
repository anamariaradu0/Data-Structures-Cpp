// Copyright 2019 Ana-Maria Radu
#include <list>
#include <iterator>
#include <string>
#include "headers/hashing_function.h"
#include "headers/hashtable.h"

template <typename Tkey, typename Tvalue>
Hashtable<Tkey, Tvalue>::Hashtable() {
	this->size = 0;
	this->capacity = 0;
}

template <typename Tkey, typename Tvalue>
Hashtable<Tkey, Tvalue>::~Hashtable() {
	delete[] H;
}

template <typename Tkey, typename Tvalue>
void Hashtable<Tkey, Tvalue>::modify_hash(int capacity, int (*h)(Tkey)) {
	size = 0;
	this->capacity = capacity;
	H = new std::list<struct Information<Tkey, Tvalue>>[capacity];
	this->hash = h;
}

template <typename Tkey, typename Tvalue>
void Hashtable<Tkey, Tvalue>::put(Tkey key, Tvalue value) {
	int index = smart_hash(key);
	index %= capacity;
	typename std::list<struct Information<Tkey, Tvalue>>::iterator it;
	for (it = H[index].begin(); it != H[index].end(); ++it) {
	  	if (it->key == key) {
			it->value = value;
			return;
	  	}
	}
	struct Information<Tkey, Tvalue> tmp;
	tmp.key = key;
	tmp.value = value;
	H[index].push_back(tmp);
	size++;
}

template <typename Tkey, typename Tvalue>
void Hashtable<Tkey, Tvalue>::remove(Tkey key) {
	int index = smart_hash(key);
	index %= capacity;
	typename std::list<struct Information<Tkey, Tvalue>>::iterator it;
	for (it = H[index].begin(); it != H[index].end(); ++it) {
	  	if (it->key == key) {
			it = H[index].erase(it);
			size--;
			return;
	  	}
	}
}

template <typename Tkey, typename Tvalue>
Tvalue Hashtable<Tkey, Tvalue>::get(Tkey key) {
	int index = smart_hash(key);
	index %= capacity;
	typename std::list<struct Information<Tkey, Tvalue>>::iterator it;
	for (it = H[index].begin(); it != H[index].end(); ++it) {
		if (it->key == key) {
			return it->value;
		}
	}
	return Tvalue{};
}

template <typename Tkey, typename Tvalue>
bool Hashtable<Tkey, Tvalue>::has_key(Tkey key) {
	int index = smart_hash(key);
	index %= capacity;
	typename std::list<struct Information<Tkey, Tvalue>>::iterator it;
	for (it = H[index].begin(); it != H[index].end(); ++it) {
	  	if (it->key == key) {
			return true;
	  	}
	}
	return false;
}

template <typename Tkey, typename Tvalue>
std::list<struct Information<Tkey, Tvalue>>*
Hashtable<Tkey, Tvalue>::getHashtable() {
	return H;
}

template <typename Tkey, typename Tvalue>
int Hashtable<Tkey, Tvalue>::get_size() {
	return size;
}

template <typename Tkey, typename Tvalue>
int Hashtable<Tkey, Tvalue>::get_capacity() {
	return capacity;
}

template class Information<std::string, int>;
template class Hashtable<std::string, int>;
