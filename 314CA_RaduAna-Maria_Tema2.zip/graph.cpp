// Copyright 2019 Radu Ana-Maria
#include "headers/graph.h"
#include <map>
#include <vector>
#include <queue>


template <typename T>
Node<T>::Node() {}

template <typename T>
Graph<T>::Graph() {
    this->size = 0;
}

template <typename T>
void Graph<T>::modify_size(int size) {
    this->size = size;
    for (int i = 0; i < size; i++) {
        nodes.push_back(Node<T>{});
    }
}

template <typename T>
void Graph<T>::add_edge(T src, T dst) {
    nodes[src].neighbors.push_back(dst);
}

template <typename T>
void Graph<T>::remove_edge(T src, T dst) {
    int noNeighborsSrc = nodes[src].neighbors.size();
    for (int i = 0; i < noNeighborsSrc; i++) {
        if (nodes[src].neighbors[i] == dst) {
            nodes[src].neighbors.erase(nodes[src].neighbors.begin() + i);
            break;
        }
    }
}

template <typename T>
bool Graph<T>::has_edge(T src, T dst) {
    int noNeighborsSrc = nodes[src].neighbors.size();
    for (int i = 0; i < noNeighborsSrc; i++) {
        if (nodes[src].neighbors[i] == dst) {
            return true;
        }
    }
    return false;
}

template <typename T>
std::vector<T> Graph<T>::get_neighbors(T node) {
    return nodes[node].neighbors;
}

template <typename T>
int Graph<T>::get_size() {
    return size;
}

template <typename T>
bool Graph<T>::BFS_path(T src, T dest) {
    if (src == dest) {
        return true;
    }

    bool *viz;
    viz = new bool[size]{};

    for (int i = 0; i < size; ++i) {
    	viz[i] = false;
    }

    std::queue<T> q;
    q.push(src);
    viz[src] = true;
    while (!q.empty()) {
        T node = q.front();
        q.pop();
        int noNeighborsNode = nodes[node].neighbors.size();
        for (int i = 0; i < noNeighborsNode; ++i) {
            if (nodes[node].neighbors[i] == dest) {
                delete []viz;
                return true;
            }

            if (viz[nodes[node].neighbors[i]] == false) {
                viz[nodes[node].neighbors[i]] = true;
                q.push(nodes[node].neighbors[i]);
            }
        }
    }

    delete []viz;
    return false;
}

template <typename T>
int Graph<T>::BFS_path_length(T src, T dest) {
    if (src == dest) {
        return 0;
    }
    std::queue<T> q;
    bool *viz;
    viz = new bool[size]{};
    int *dist = new int[size]{};
    for (int i = 0; i < size; ++i) {
        viz[i] = false;
        dist[i] = -1;
    }

    viz[src] = true;
    dist[src] = 0;
    q.push(src);
    while (!q.empty()) {
        T node =  q.front();
        q.pop();
        int noNeighborsNode = nodes[node].neighbors.size();
        for (int i = 0; i < noNeighborsNode; ++i) {
            if (viz[nodes[node].neighbors[i]] == false) {
                viz[nodes[node].neighbors[i]] = true;
                dist[nodes[node].neighbors[i]] = dist[node] + 1;
                q.push(nodes[node].neighbors[i]);
            }

            if (nodes[node].neighbors[i] == dest) {
                delete []viz;
                int distance = dist[dest];
                delete []dist;
                return distance;
            }
        }
    }
    delete []viz;
    delete []dist;
    return -1;
}

template class Graph<int>;
template class Node<int>;
