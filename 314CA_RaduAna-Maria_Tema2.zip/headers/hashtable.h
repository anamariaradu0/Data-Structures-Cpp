// Copyright 2019 Ana-Maria Radu
#ifndef HASHTABLE_H_
#define HASHTABLE_H_

#include <list>
#include <iterator>
#include "hashing_function.h"

template <typename Tkey, typename Tvalue>
struct Information {
	Tkey key;
	Tvalue value;
};

template <typename Tkey, typename Tvalue>
class Hashtable {
 public:
  	std::list<struct Information<Tkey, Tvalue>> *H;
  	int size;
  	int capacity;
  	int (*hash)(Tkey);

	// Constructor
	Hashtable();

	// Destructor
	~Hashtable();

	// Method that modifies the size of an already existing hashtable
	void modify_hash(int capacity, int (*h)(Tkey));

	// Insertion in hashtable
	void put(Tkey key, Tvalue value);

	// Removal from hashtable
	void remove(Tkey key);

	// Return the value of a given key
	Tvalue get(Tkey key);

	// Decide if a given key already exists
	bool has_key(Tkey key);

	// Getters
	std::list<struct Information<Tkey, Tvalue>>* getHashtable();
	int get_size();
	int get_capacity();
};

#endif  // HASHTABLE_H_
