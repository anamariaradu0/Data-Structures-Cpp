// Copyright 2019 Ana-Maria Radu
#ifndef GRAPH_H_
#define GRAPH_H_

#include <map>
#include <vector>
#include <queue>

template <typename T>
class Node {
 public:
    std::vector<T> neighbors;

    Node();
};

template <typename T>
class Graph {
 public:
    std::vector<Node<T>> nodes;
    int size;

    // Constructor
    Graph();

    // Modifying the size of an already declared Graph
    void modify_size(int size);

    // Adding an edge between a source and a destination
    void add_edge(T src, T dst);

    // Removing the edge between a source and a destination
    void remove_edge(T src, T dst);

    // Deciding whether there is an edge between source and destination
    bool has_edge(T src, T dst);

    std::vector<T> get_neighbors(T);

    int get_size();

    // Breadth-First Search transversal that decides whether there is a
    // valid path between two nodes
    bool BFS_path(T src, T dest);

    // Breadth-First Search transversal that returns the minimum distance
    // between two nodes
    int BFS_path_length(T src, T dest);
};

#endif  // GRAPH_H_
