// Copyright 2019 Ana-Maria Radu
#ifndef HASHING_FUNCTION_H_
#define HASHING_FUNCTION_H_
#include <string>

int smart_hash(std::string str);

#endif  // HASHING_FUNCTION_H_
