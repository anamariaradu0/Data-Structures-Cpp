// Copyright 2019 Ana-Maria Radu
#include "headers/hashing_function.h"
#include <string>

int smart_hash(std::string str) {
  int len = str.size();
  int index = 0;
  int N = 1234, x = 19;
  for (int i = 0; i < len; i++) {
    index = ((index * x) + str[i]) % N;
  }
  return index;
}
