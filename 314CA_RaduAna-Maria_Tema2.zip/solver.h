// Copyright 2019 SD_Homework_Team

#ifndef SOLVER_H_
#define SOLVER_H_
#include <fstream>
#include <iostream>
#include <string>

#include "headers/hashtable.h"
#include "headers/graph.h"
#include "headers/hashing_function.h"

class solver {
 public:
	Hashtable<std::string, int> Cross_hash;
	Graph<int> Map;

	void task1_solver(std::ifstream& fin, std::ofstream& fout) {
		int crossroads, streets;
		fin >> crossroads >> streets;
		Map.modify_size(crossroads);
		Cross_hash.modify_hash(crossroads, &smart_hash);

		for (int i = 0; i < crossroads; ++i) {
			std::string cross_name;
			fin >> cross_name;
			Cross_hash.put(cross_name, i);
		}

		for (int i = 0; i < streets; ++i) {
			std::string cross_a, cross_b;
			fin >> cross_a >> cross_b;

			int index_a = Cross_hash.get(cross_a);
			int index_b = Cross_hash.get(cross_b);

			Map.add_edge(index_a, index_b);
			Map.nodes[index_a].neighbors.push_back(index_b);
		}

		int queries;
		fin >> queries;

		for (int i = 0; i < queries; ++i) {
			std::string cross_a, cross_b;
			fin >> cross_a >> cross_b;

			int index_a = Cross_hash.get(cross_a);
			int index_b = Cross_hash.get(cross_b);
			if (Map.BFS_path(index_a, index_b)) {
				fout << "y\n";
			} else {
				fout << "n\n";
			}
		}
	}

	void task2_solver(std::ifstream& fin, std::ofstream& fout) {
		int queries_2;
		fin >> queries_2;

		for (int i = 0; i < queries_2; ++i) {
			std::string cross_a, cross_b;
			fin >> cross_a >> cross_b;

			int index_a = Cross_hash.get(cross_a);
			int index_b = Cross_hash.get(cross_b);
			fout << Map.BFS_path_length(index_a, index_b) << "\n";
		}
	}

	void task3_solver(std::ifstream& fin, std::ofstream& fout) {
		int queries_3;
		fin >> queries_3;
		std::string cross_a, cross_b;

		char task;
		int task_index;
		for (int i = 0; i < queries_3; ++i) {
			fin >> task;

			if (task == 'c') {
				fin >> cross_a >> cross_b >> task_index;
				int index_a = Cross_hash.get(cross_a);
				int index_b = Cross_hash.get(cross_b);
				switch (task_index) {
					case 0:
						Map.add_edge(index_a, index_b);
						Map.nodes[index_a].neighbors.push_back(index_b);
						break;
					case 1:
						Map.remove_edge(index_a, index_b);
						Map.remove_edge(index_b, index_a);
						break;
					case 2:
						Map.add_edge(index_a, index_b);
						Map.nodes[index_a].neighbors.push_back(index_b);
						Map.add_edge(index_b, index_a);
						Map.nodes[index_b].neighbors.push_back(index_a);
						break;
					case 3:
						// inversarea drumului
						if (Map.has_edge(index_a, index_b) == true
							&& Map.has_edge(index_b, index_a) == false) {
							Map.remove_edge(index_a, index_b);
							Map.add_edge(index_b, index_a);
						} else if (Map.has_edge(index_a, index_b) == false
							&& Map.has_edge(index_b, index_a) == true) {
							Map.remove_edge(index_b, index_a);
							Map.add_edge(index_a, index_b);
						}
						break;
				}
			} else {
				fin >> cross_a >> cross_b >> task_index;
				int index_a = Cross_hash.get(cross_a);
				int index_b = Cross_hash.get(cross_b);
				switch (task_index) {
					case 0:
						if (Map.BFS_path(index_a, index_b)) {
							fout << "y\n";
						} else {
							fout << "n\n";
						}
						break;
					case 1:
						fout << Map.BFS_path_length(index_a, index_b)
							<< "\n";
						break;
					case 2:
						std::string cross_c;
						fin >> cross_c;
						int index_c = Cross_hash.get(cross_c);
						int p_len;
						if (Map.BFS_path_length(index_a, index_c) != -1 &&
							Map.BFS_path_length(index_c, index_b) != -1) {
							p_len = Map.BFS_path_length(index_a, index_c)
								+ Map.BFS_path_length(index_c, index_b);
							fout << p_len << "\n";
						} else {
							fout << -1 << "\n";
						}
						break;
				}
			}
		}
	}

	void task4_solver(std::ifstream& fin, std::ofstream& fout) {
		int queries_4;
		fin >> queries_4;
		fout << queries_4;
	}

	void task5_solver(std::ifstream& fin, std::ofstream& fout) {
		char queries_5;
		fin >> queries_5;
		fout << queries_5;
	}
};

#endif  // SOLVER_H_
